package edu.penn.rtg.schedulingapp.old;

/**
 * This class helps unify RBD structures and Task lists, allowing for easier
 * addition to components
 */
public interface ComponentSubUnit {
	public boolean isRBT();
}
