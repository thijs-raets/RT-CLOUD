package edu.penn.rtg.schedulingapp.nalgo;

import edu.penn.rtg.schedulingapp.basic.ResModel;


public interface PrmAlgo {
	public ResModel getRes();
}
