package edu.penn.rtg.schedulingapp.input.treeGUI;


public interface CartsI {
	public void convertToXML();
}
