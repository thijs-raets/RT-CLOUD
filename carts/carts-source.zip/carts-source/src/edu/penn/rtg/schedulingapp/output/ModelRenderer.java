package edu.penn.rtg.schedulingapp.output;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Node for Model Value in Output View
 */
public class ModelRenderer extends DefaultMutableTreeNode {
	public ModelRenderer(String myName) {
		super(myName);
	}
}