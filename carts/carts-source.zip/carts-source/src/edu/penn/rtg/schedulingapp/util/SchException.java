package edu.penn.rtg.schedulingapp.util;

@SuppressWarnings("serial")
public class SchException extends Exception {

}
