package edu.penn.rtg.schedulingapp.output;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Node for Resource Model in Output View
 */
public class ResourceModelRenderer extends DefaultMutableTreeNode {
	public ResourceModelRenderer(String myName) {
		super(myName);
	}
}