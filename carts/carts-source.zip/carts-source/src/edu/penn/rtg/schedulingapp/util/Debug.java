package edu.penn.rtg.schedulingapp.util;

public class Debug {
	public static final boolean debugOn=true;
	//public static final boolean debugOn=false;
	public static void prn(String s)
	{
		if(!debugOn) return;
		System.out.println(s);
	}
	public static void prn(int val) {
		if(!debugOn) return;
		System.out.println(val);
	}
	public static void prn(double val) {
		if(!debugOn) return;
		System.out.println(val);
	}
}
