package edu.penn.rtg.schedulingapp.output;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Node for Processed Component in Tree View
 */
public class CompOutputRenderer extends DefaultMutableTreeNode {
	public CompOutputRenderer(String myName) {
		super(myName);
	}
}
