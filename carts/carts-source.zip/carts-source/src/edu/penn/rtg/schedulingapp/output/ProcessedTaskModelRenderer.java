package edu.penn.rtg.schedulingapp.output;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Node for Processed Task Model in Output View
 */
public class ProcessedTaskModelRenderer extends DefaultMutableTreeNode {
	public ProcessedTaskModelRenderer(String myName) {
		super(myName);
	}
}