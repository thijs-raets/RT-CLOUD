package edu.penn.rtg.schedulingapp.input.treeGUI;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

public class CartsTreeSelLis implements TreeSelectionListener {
	/**
	 * Presently, no handler for this event
	 */

	@Override
	public void valueChanged(TreeSelectionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
